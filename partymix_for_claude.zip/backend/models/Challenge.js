const mongoose = require('mongoose');
const s = new mongoose.Schema({
  text: { type: String, required: true },
  category: { type: String, enum: ['telepatia','perguntas','desenho','mimica','proibido','palavra','acao','verdade','consequencia','cultura','desporto','musica','cinema','erotico','romantico','picante','roleplay','casal_pergunta','dados'], required: true },
  mode_type: { type: String, enum: ['couple','friends','family','all'], required: true },
  difficulty: { type: String, enum: ['facil','medio','dificil'], default: 'medio' },
  answer: { type: String, default: '' },
  forbiddenWords: [{ type: String }],
  sips_penalty: { type: Number, default: 2 },
  time_limit: { type: Number, default: 0 },
  is_ongoing: { type: Boolean, default: false },
  ongoing_rounds: { type: Number, default: 0 },
  ongoing_instruction: { type: String, default: '' }
}, { timestamps: true });
module.exports = mongoose.model('Challenge', s);