// Import PartyMix content packs from JSON without hardcoding card lists in code.
// Usage: node seeds/importPack.js ../data/example-pack.json

const fs = require('fs')
const path = require('path')
const mongoose = require('mongoose')
require('dotenv').config({ path: path.join(__dirname, '../.env') })

const Card = require('../models/Card')
const Challenge = require('../models/Challenge')

const MONGO_URI = process.env.MONGODB_URI || 'mongodb://localhost:27017/partymix'

const CHALLENGE_MODES = new Set(['family', 'friends', 'couple', 'drink'])
const CARD_MODES = new Set(['cards'])
const DEFAULT_CARD_CATEGORY = 'geral'

const CATEGORY_MAP = {
  telepatia: 'telepatia',
  perguntas: 'perguntas',
  desenho: 'desenho',
  mimica: 'mimica',
  proibido: 'proibido',
  beber: 'acao',
  regra: 'consequencia',
  desafio: 'acao',
  duelo: 'acao',
  poder: 'acao',
  sorte: 'consequencia',
  romantico: 'romantico',
  picante: 'picante',
  verdade: 'verdade',
  acao: 'acao',
  roleplay: 'roleplay',
  quiz: 'casal_pergunta',
}

function asArray(value) {
  return Array.isArray(value) ? value : []
}

function clean(value, max = 300) {
  return String(value ?? '').replace(/<[^>]*>/g, '').trim().slice(0, max)
}

function normalizeChallengeMode(mode) {
  // The DB currently stores party/drink style challenges under friends.
  return mode === 'drink' ? 'friends' : mode
}

function normalizeCardEntry(entry, isBlack) {
  if (typeof entry === 'string') {
    return {
      text: clean(entry),
      category: DEFAULT_CARD_CATEGORY,
      is_black: isBlack,
      mode_type: 'cards',
    }
  }

  return {
    text: clean(entry.text),
    category: clean(entry.category, 40) || DEFAULT_CARD_CATEGORY,
    is_black: entry.is_black ?? entry.isBlack ?? isBlack,
    mode_type: 'cards',
  }
}

function normalizeChallengeEntry(entry, mode, type) {
  const raw = typeof entry === 'string' ? { text: entry } : entry
  const category = CATEGORY_MAP[type] || CATEGORY_MAP[raw.category] || raw.category || 'acao'

  return {
    text: clean(raw.text),
    category,
    mode_type: normalizeChallengeMode(mode),
    difficulty: raw.difficulty || 'medio',
    answer: clean(raw.answer, 200),
    forbiddenWords: asArray(raw.forbiddenWords).map((w) => clean(w, 40)).filter(Boolean).slice(0, 5),
    sips_penalty: Number.isFinite(Number(raw.sips_penalty)) ? Number(raw.sips_penalty) : mode === 'friends' || mode === 'drink' ? 2 : 0,
    time_limit: Number.isFinite(Number(raw.time_limit)) ? Number(raw.time_limit) : defaultTimeLimit(type),
    is_ongoing: Boolean(raw.is_ongoing),
    ongoing_rounds: Number.isFinite(Number(raw.ongoing_rounds)) ? Number(raw.ongoing_rounds) : 0,
    ongoing_instruction: clean(raw.ongoing_instruction, 300),
  }
}

function defaultTimeLimit(type) {
  if (type === 'desenho') return 60
  if (type === 'mimica') return 45
  if (type === 'telepatia') return 10
  return 0
}

async function insertUnique(Model, doc, counters) {
  if (!doc.text) {
    counters.invalid += 1
    return
  }

  const exists = await Model.findOne({ text: doc.text })
  if (exists) {
    counters.skipped += 1
    return
  }

  await new Model(doc).save()
  counters.inserted += 1
}

function collectCards(pack) {
  const out = []
  const cards = pack.mode === 'cards'
    ? { white: pack.white || pack.cards?.white, black: pack.black || pack.cards?.black }
    : pack.cards || pack.modes?.cards || {}
  for (const entry of asArray(cards.white)) out.push(normalizeCardEntry(entry, false))
  for (const entry of asArray(cards.black)) out.push(normalizeCardEntry(entry, true))
  return out
}

function collectChallenges(pack) {
  const out = []

  if (CHALLENGE_MODES.has(pack.mode)) {
    const content = pack.categories || pack.items || pack.challengesByType || {}
    for (const [type, entries] of Object.entries(content)) {
      for (const entry of asArray(entries)) out.push(normalizeChallengeEntry(entry, pack.mode, type))
    }
  }

  for (const [mode, content] of Object.entries(pack.modes || {})) {
    if (!CHALLENGE_MODES.has(mode) || CARD_MODES.has(mode)) continue
    for (const [type, entries] of Object.entries(content || {})) {
      for (const entry of asArray(entries)) out.push(normalizeChallengeEntry(entry, mode, type))
    }
  }

  for (const entry of asArray(pack.challenges)) {
    const mode = entry.mode || pack.mode || 'friends'
    const type = entry.type || entry.cardType || entry.category || 'desafio'
    out.push(normalizeChallengeEntry(entry, mode, type))
  }

  return out
}

async function main() {
  const fileArg = process.argv[2]
  if (!fileArg) {
    console.error('Usage: node seeds/importPack.js <pack.json>')
    process.exit(1)
  }

  const filePath = path.resolve(process.cwd(), fileArg)
  const pack = JSON.parse(fs.readFileSync(filePath, 'utf8'))

  const cards = collectCards(pack)
  const challenges = collectChallenges(pack)
  const cardCounters = { inserted: 0, skipped: 0, invalid: 0 }
  const challengeCounters = { inserted: 0, skipped: 0, invalid: 0 }

  await mongoose.connect(MONGO_URI)
  for (const card of cards) await insertUnique(Card, card, cardCounters)
  for (const challenge of challenges) await insertUnique(Challenge, challenge, challengeCounters)
  await mongoose.disconnect()

  console.log(`Imported pack: ${pack.name || path.basename(filePath)}`)
  console.log(`Cards: ${cardCounters.inserted} inserted, ${cardCounters.skipped} skipped, ${cardCounters.invalid} invalid`)
  console.log(`Challenges: ${challengeCounters.inserted} inserted, ${challengeCounters.skipped} skipped, ${challengeCounters.invalid} invalid`)
}

main().catch(async (err) => {
  console.error('Import failed:', err.message)
  await mongoose.disconnect().catch(() => {})
  process.exit(1)
})
